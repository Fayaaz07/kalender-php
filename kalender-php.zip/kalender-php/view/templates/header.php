<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>PHP Calendar</title>	
		<link rel="stylesheet" href="<?= URL ?>/css/style.css">
	</head>
	<body>
		<header>
			<section id="head">PHP/SQL Calendar</section>
			<ul>
				<li><a href="<?= URL ?>calendar/index">Startpagina</a></li>
				<li><a href="<?= URL ?>calendar/create">Toevoegen</a></li>
			</ul>
		</header>

		<main>