<?php

function index()
{
	render("calendar/index");	
}